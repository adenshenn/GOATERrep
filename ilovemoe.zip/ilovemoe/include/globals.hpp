#ifndef _GLOBALS_HPP_
#define _GLOBALS_HPP_

#define LEEWAY 50
#define DEFAULTKP 0.6

#define FLPORT 3
// #define MLPORT 2
#define BLPORT 14
#define FRPORT 10
// #define MRPORT 5
#define BRPORT 19
// #define INPORT 7
#define ILPORT 2
#define IRPORT 9
#define LLPORT 11
#define LRPORT 20

#endif