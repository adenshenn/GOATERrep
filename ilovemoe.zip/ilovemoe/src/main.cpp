#include "main.h"

double ERRL, ERRR, CURRL, CURRR, KPBS = 0.5, TARGL = 0,TARGR = 0, LPOW, RPOW; 
void basemove(double L, double R, double KPBS) {
	Motor FL (FLPORT);
	// Motor ML (MLPORT);
	Motor BL (BLPORT);
	Motor FR (FRPORT);
	// Motor MR (MRPORT);
	Motor BR (BRPORT);

	TARGL = FL.get_position() + L;
	TARGR = FR.get_position() + R;

	ERRL = TARGL - FL.get_position();
	ERRR = TARGR - FR.get_position();
	

	while (fabs(ERRL) >= LEEWAY || fabs(ERRR) >= LEEWAY) {
		CURRL = FL.get_position();
		CURRR = FR.get_position();
		ERRL = TARGL - CURRL;
		ERRR = TARGR - CURRR;
		LPOW = ERRL * KPBS;
		RPOW = ERRR * KPBS;
		FL.move(LPOW);
		// ML.move(LPOW);
		BL.move(LPOW);
		FR.move(RPOW);
		// MR.move(RPOW);
		BR.move(RPOW);
		delay(50);
	}
	FL.move(0);
	FR.move(0);
	BL.move(0);
	BR.move(0);
}

void basemove(double L, double R) {
	basemove(L,R,DEFAULTKP);
}

double TARG = 0;
int POS = 1;
double ERRLF, KPLF = 1, CURRLF;

// void armTask(void*ignore) {
// 	delay(500);
// 	Motor FL (FLPORT);
// 	Motor ML (MLPORT);
// 	Motor BL (BLPORT);
// 	Motor FR (FRPORT);
// 	Motor MR (MRPORT);
// 	Motor BR (BRPORT);
// 	Motor IN (INPORT);
// 	Motor LF (LFPORT);
// 	Motor IL (ILPORT);
// 	Motor IR (IRPORT);
// 	Motor LL (LLPORT);
// 	Motor LR (LRPORT);

// 	Controller master (E_CONTROLLER_MASTER);
// 	while (true) {
// 		switch (POS) {
// 			case 1: TARG = -50;
// 			break;
// 			case 2: TARG = -300;
// 			break;
// 			case 3: TARG = -600;
// 			break;
// 		}	
// 		CURRLF = LR.get_position();
// 		ERRLF = TARG - CURRLF;
// 		LL.move(ERRLF * KPLF);
// 		LR.move(ERRLF * KPLF);

// 		delay(50);
// 	}
// }

// void on_center_button() {

// }

void initialize() {
	Motor FL (FLPORT, E_MOTOR_GEARSET_18, false, E_MOTOR_ENCODER_DEGREES);
	// Motor ML (MLPORT, E_MOTOR_GEARSET_06, true, E_MOTOR_ENCODER_DEGREES);
	Motor BL (BLPORT, E_MOTOR_GEARSET_18, false, E_MOTOR_ENCODER_DEGREES);
	Motor FR (FRPORT, E_MOTOR_GEARSET_18, true, E_MOTOR_ENCODER_DEGREES);
	// Motor MR (MRPORT, E_MOTOR_GEARSET_06, true, E_MOTOR_ENCODER_DEGREES);
	Motor BR (BRPORT, E_MOTOR_GEARSET_18, true, E_MOTOR_ENCODER_DEGREES);
	// Motor IN (INPORT, E_MOTOR_GEARSET_06, true, E_MOTOR_ENCODER_DEGREES);
	// Motor LF (LFPORT, E_MOTOR_GEARSET_06, true, E_MOTOR_ENCODER_DEGREES);
	Motor IL (ILPORT, E_MOTOR_GEARSET_18, false, E_MOTOR_ENCODER_DEGREES);
	Motor IR (IRPORT, E_MOTOR_GEARSET_18, true, E_MOTOR_ENCODER_DEGREES);
	Motor LL (LLPORT, E_MOTOR_GEARSET_18, true, E_MOTOR_ENCODER_DEGREES);
	Motor LR (LRPORT, E_MOTOR_GEARSET_18, false, E_MOTOR_ENCODER_DEGREES);
	

	Controller master (E_CONTROLLER_MASTER);

	// Task armTaskInitialise(armTask, (void*)"PROS",TASK_PRIORITY_DEFAULT,TASK_STACK_DEPTH_DEFAULT,"task");
}

void disabled() {}

void competition_initialize() {}

void autonomous() {
	Motor FL (FLPORT);
	// Motor ML (MLPORT);
	Motor BL (BLPORT);
	Motor FR (FRPORT);
	// Motor MR (MRPORT);
	Motor BR (BRPORT);
	// Motor IN (INPORT);
	// Motor LF (LFPORT);
	Motor IL (ILPORT);
	Motor IR (IRPORT);
	Motor LL (LLPORT);
	Motor LR (LRPORT);

	Controller master (E_CONTROLLER_MASTER);

	// IL.move(127);
	// IR.move(127);
	// basemove(1000, 1000);
	// delay(2000);
	// IL.move(0);
	// IR.move(0);
	// POS = 3;
	// delay(3000);
	// POS = 1;
	// IL.move(-127);
	// IR.move(-127);
	// delay(2000);
	// IL.move(0);
	// IR.move(0);
	// basemove(300,-300);
	// delay(1000);
	// basemove(1000,0);

	IL.move(127);
	IR.move(127);
	basemove(100, 100);
	delay(3000);
	basemove(-800, -800);
	delay(100);
	basemove(350, -350, KPBS = 0.4);
	delay(50);
	basemove(800, 800);
	delay(2000);
	basemove(0,200);
	IL.move(-127);
	IR.move(-127);
	basemove(-100, -100, KPBS = 0.8);
	delay(2000);
	POS = 2;
	delay(3000);
	basemove(500, 500);

}


void opcontrol() {
	Motor FL (FLPORT);
	// Motor ML (MLPORT);
	Motor BL (BLPORT);
	Motor FR (FRPORT);
	// Motor MR (MRPORT);
	Motor BR (BRPORT);
	// Motor IN (INPORT);
	// Motor LF (LFPORT);
	Motor IL (ILPORT);
	Motor IR (IRPORT);
	Motor LL (LLPORT);
	Motor LR (LRPORT);

	Controller master (E_CONTROLLER_MASTER);
	// ERR = TARG - LF.get_position();

	delay(50);

	while (true) {
		LPOW = master.get_analog(E_CONTROLLER_ANALOG_LEFT_Y);
		RPOW = master.get_analog(E_CONTROLLER_ANALOG_RIGHT_Y);
		FL.move(LPOW);
		// ML.move(LPOW);
		BL.move(LPOW);
		FR.move(RPOW);
		// MR.move(RPOW);
		BR.move(RPOW);

		IL.move(127 * (master.get_digital(E_CONTROLLER_DIGITAL_L1) - master.get_digital(E_CONTROLLER_DIGITAL_L2)));
		IR.move(127 * (master.get_digital(E_CONTROLLER_DIGITAL_L1) - master.get_digital(E_CONTROLLER_DIGITAL_L2)));

		if (master.get_digital_new_press(E_CONTROLLER_DIGITAL_R1)){
			if (POS < 3){
				POS += 1;
			}
		}
				
		if (master.get_digital_new_press(E_CONTROLLER_DIGITAL_R2)){
			if (POS > 1){
				POS -= 1;
			}
		}
		
		
		delay(50);		
	}
}


