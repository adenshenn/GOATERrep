#ifndef _GLOBALS_HPP_
#define _GLOBALS_HPP_


#define FLPORT 1
#define FRPORT 2
#define BLPORT 3
#define BRPORT 4
#define TLPORT 5
#define TRPORT 6
#define INPORT 7
#define CAPORT 8 
#define HAPORT 1
#define PTPORT 2
#define RWPORT 3
#define LWPORT 4



#endif