#ifndef _MECHLIB_HPP_
#define _MECHLIB_HPP_

#define KP 1
#define INPERDEG 2
#define botR 10
#define leeway 5
extern bool pid_enabled;
void cata(void*ignore);
void shoot();

#endif