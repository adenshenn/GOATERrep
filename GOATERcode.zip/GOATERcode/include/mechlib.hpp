#ifndef _MECHLIB_HPP_
#define _MECHLIB_HPP_

#define KP 100

void cata(void*ignore);
void shoot();

#endif