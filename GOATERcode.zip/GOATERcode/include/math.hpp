#ifndef _MATH_HPP_
#define _MATH_HPP_
#define torad 0.0174533
double abscap(double val, double cap = 127);

#endif 