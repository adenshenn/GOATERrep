#ifndef _MATH_HPP_
#define _MATH_HPP_

double abscap(double val, double cap = 127);

#endif 