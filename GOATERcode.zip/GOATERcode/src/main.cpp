#include "main.h"

double leftPow , rightPow;
bool arcadeMode = false;
bool hangState = false;
bool PTOState = false;
bool LwingState = false;
bool RwingState = false;
bool TwingState = false;

void initialize() {
	//base (6 motors)
	Motor FL (FLPORT, E_MOTOR_GEARSET_06, false, E_MOTOR_ENCODER_DEGREES);
	Motor FR (FRPORT, E_MOTOR_GEARSET_06, false, E_MOTOR_ENCODER_DEGREES);
	Motor TR (TRPORT, E_MOTOR_GEARSET_06, true, E_MOTOR_ENCODER_DEGREES);
	Motor TL (TLPORT, E_MOTOR_GEARSET_06, true, E_MOTOR_ENCODER_DEGREES);
	Motor BL (BLPORT, E_MOTOR_GEARSET_06, false, E_MOTOR_ENCODER_DEGREES);
	Motor BR (BRPORT, E_MOTOR_GEARSET_06, false, E_MOTOR_ENCODER_DEGREES);
	//mechanisms (2motor slapper, 1motor intake)
	Motor IN (INPORT, E_MOTOR_GEARSET_06, true, E_MOTOR_ENCODER_DEGREES);
	Motor CL (CLPORT, E_MOTOR_GEARSET_18, true, E_MOTOR_ENCODER_DEGREES);
	Motor CR (CRPORT, E_MOTOR_GEARSET_18, false, E_MOTOR_ENCODER_DEGREES);
	//pneumatics (2piston wings, 1piston hang, 2piston PTO)
	ADIDigitalOut HA (HAPORT);
	ADIDigitalOut PT (PTPORT);
	ADIDigitalOut LW (LWPORT);
	ADIDigitalOut RW (RWPORT);
	Controller master (E_CONTROLLER_MASTER);

}

void disabled() {}
void competition_initialize() {}
void autonomous() {}
void opcontrol() {
	Motor FL (FLPORT);
	Motor FR (FRPORT);
	Motor TR (TRPORT);
	Motor TL (TLPORT);
	Motor BL (BLPORT);
	Motor BR (BRPORT);
	Motor CL (CLPORT);
	Motor CR (CRPORT);
	Motor IN (INPORT);
	ADIDigitalOut HA (HAPORT);
	ADIDigitalOut PT (PTPORT);
	ADIDigitalOut LW (LWPORT);
	ADIDigitalOut RW (RWPORT);

	FL.set_brake_mode(E_MOTOR_BRAKE_BRAKE);
	BL.set_brake_mode(E_MOTOR_BRAKE_BRAKE);
	TL.set_brake_mode(E_MOTOR_BRAKE_BRAKE);
	FR.set_brake_mode(E_MOTOR_BRAKE_BRAKE);
	BR.set_brake_mode(E_MOTOR_BRAKE_BRAKE);
	TR.set_brake_mode(E_MOTOR_BRAKE_BRAKE);

	Controller master (E_CONTROLLER_MASTER);
	while (true) {
		//base
		if (master.get_digital(E_CONTROLLER_DIGITAL_X)) {
			arcadeMode = !arcadeMode;
		}
		if (arcadeMode) {
			leftPow = master.get_analog(E_CONTROLLER_ANALOG_LEFT_Y) + master.get_analog(E_CONTROLLER_ANALOG_RIGHT_X);
			rightPow = master.get_analog(E_CONTROLLER_ANALOG_LEFT_Y) - master.get_analog(E_CONTROLLER_ANALOG_RIGHT_X);
		}
		else {
			leftPow = master.get_analog (E_CONTROLLER_ANALOG_LEFT_Y);
			rightPow = master.get_analog (E_CONTROLLER_ANALOG_RIGHT_Y);
		}
		FL.move(leftPow);
		BL.move(leftPow);
		TL.move(leftPow);
		FR.move(rightPow);
		BR.move(rightPow);
		TR.move(rightPow);

		//intake
		IN.move((master.get_digital(E_CONTROLLER_DIGITAL_R1) - master.get_digital(E_CONTROLLER_DIGITAL_R2))*127);

		//pneumatic
		if (master.get_digital(E_CONTROLLER_DIGITAL_DOWN)) {
			hangState = !hangState;
		}

		if (master.get_digital(E_CONTROLLER_DIGITAL_A)) {
			PTOState = !PTOState;
		}
		if (master.get_digital(E_CONTROLLER_DIGITAL_L2)) {
			TwingState = !TwingState;
			RwingState = TwingState;
			LwingState = TwingState;
		}
		if (master.get_digital(E_CONTROLLER_DIGITAL_LEFT)) {
			LwingState = !LwingState;
			if (LwingState == RwingState) {
				TwingState = !TwingState;
			}
		}
		if (master.get_digital(E_CONTROLLER_DIGITAL_RIGHT)) {
			RwingState = !RwingState;
			if (LwingState == RwingState) {
				TwingState = !TwingState;
			}
		}
		if (master.get_digital(E_CONTROLLER_DIGITAL_L1)) {
			shoot();
		}
		PT.set_value(PTOState);
		HA.set_value(hangState);
		LW.set_value(LwingState);
		RW.set_value(RwingState);
		
		delay(5);
		
	}
}
