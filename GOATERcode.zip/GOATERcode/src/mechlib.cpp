#include "mechlib.hpp"
#include "main.h"
// power = (kp x error) + 0
double tar = 0, err, por, cur;

// 2motor cata
void cata(void*ignore) {
    Motor CL (CLPORT);
    Motor CR (CRPORT);
    while (true) {
        cur = CL.get_position();
        err = tar - cur;
        por = KP * err;
        CL.move(por);
        CR.move(por);
        delay(5);
    }
}
void shoot() {
    tar += 1080;
}

