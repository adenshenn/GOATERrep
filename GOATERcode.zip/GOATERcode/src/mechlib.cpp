#include "main.h"
// power = (kp x error) + 0
double tar = 0, err, por, cur;
double errL, targL, encL, errR, targR, encR, powL, powR, truekP, maxPow;
bool pid_enabled = false;

// 2motor cata
void cata(void*ignore) {
    Motor CL (CLPORT);
    Motor CR (CRPORT);
    while (true) {
        cur = CL.get_position();
        err = tar - cur;
        por = KP * err;
        CL.move(por);
        CR.move(por);
        delay(5);
    }
}
void shoot() {
    tar += 1080;
}

// auton movement tasks
void baseMove(double L_dis, double R_dis, double p_KP){
    targL += L_dis/INPERDEG;
    targR += R_dis/INPERDEG;
    truekP = p_KP;

} //goes into controlMove

void baseMove(double L_dis, double R_dis){
    baseMove(L_dis, R_dis, KP);
} //goes into baseMove

void baseTurn(double B_deg, double p_KP){
    double arc = (B_deg * torad) * botR;
    baseMove (arc, -arc, p_KP);
} //goes into baseMove

void baseTurn(double B_deg){
    baseTurn(B_deg, KP);
} //goes into baseTurn above

void controlMove(void*ignore) {
	Motor FL (FLPORT);
	Motor FR (FRPORT);
	Motor TR (TRPORT);
	Motor TL (TLPORT);
	Motor BL (BLPORT);
	Motor BR (BRPORT);
	Motor CL (CLPORT);
	Motor CR (CRPORT);
	Motor IN (INPORT);
	ADIDigitalOut HA (HAPORT);
	ADIDigitalOut PT (PTPORT);
	ADIDigitalOut LW (LWPORT);
	ADIDigitalOut RW (RWPORT);

    while (true) {
        if (pid_enabled){
            errL = targL - encL;
            errR = targR - encR;
            powL = abscap(errL * truekP, maxPow);
            powR = abscap(errR * truekP,maxPow);
            
            FL.move(powL);
            BR.move(powL);
            TL.move(powL);
            FR.move(powR);
            BR.move(powR);
            TR.move(powR);
        }
        delay(5);
    } //call this like jesus
}

void baseWait (double cutoff) {
    double start = millis();
    delay(50);
    while((fabs(errL) > leeway || fabs(errR)> leeway) && millis()- start <= cutoff ){
    delay(5);
    } 
    targL = encL;
    targR = encR; //makes my power zero
}
