#include "math.h"
// power = error x kP
//to cap motor power
double abscap(double val, double cap) {
    double ret = val;
    if (val > cap) {
        ret = cap;
    }
    if (val < -cap) {
        ret = -cap;
    }
    return ret;
}


